# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['rt_from_frequency_dynamics']

package_data = \
{'': ['*']}

install_requires = \
['DateTime>=4.3,<5.0',
 'PyYAML>=6.0,<7.0',
 'jax>=0.3.10,<0.4.0',
 'jaxlib>=0.3.10,<0.4.0',
 'matplotlib>=3.5.0,<4.0.0',
 'numpy>=1.21.4,<2.0.0',
 'numpyro>=0.9.2,<0.10.0',
 'pandas>=1.3.4,<2.0.0',
 'scipy>=1.7.3,<2.0.0']

setup_kwargs = {
    'name': 'rt-from-frequency-dynamics',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'marlinfiggins',
    'author_email': 'marlinfiggins@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<3.11',
}


setup(**setup_kwargs)
